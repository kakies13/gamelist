-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(457140)
addappid(457141,0,"1f77f3d9ef1b69fc77d28031a5ed6d04cc279101faa6ffe5f1e0915b4baab79c")
addappid(457142,0,"16847f270c721a9adf7256bc88d288af678193f74c533f2cd44bccff1ceccdf4")
addappid(457143,0,"3199b2ed10129547be0ba6efa9fbb4aa5c740f09fe158c1cf9b8879fc7aba8e4")
addappid(1452490)
addappid(1452491,0,"65272efbc87a5b051b30af08129c729e7069bf5fb8152d68d21fa0588bdbaa42")
addappid(1452492,0,"0b9f63b77607bdc6f37c6bdb210dae04b2b0c754c15f23d35f821faedde16c18")
addappid(1452493,0,"c9535e00cac8b8233875f729e30bd590afc2e07204f78d4ba08391d690279210")
addappid(2952300)
addappid(2952301,0,"0aac13130570a4cb9a749ceff82c255feee2a1bf65b45505327eed962cb26157")
addappid(2952302,0,"52efd7282b10c02fdbed47f79ab3fee394692e140b4a4f6772bed739e17ce4a1")
addappid(2952303,0,"734a56752faf870ec6a0658210b60aac3f13de253df76e86374e6682c65026af")
addappid(3302470)
addappid(3302471,0,"f8bc05dcd9e0ee42b25f6aa97c7f85fc741c4d6ad98d739bdf60e771b00a3b8c")
addappid(3302472,0,"65bd88c7ebed08e9724c1a238b1f2ac37402acad5347a83dcd5ba1cc0305d452")
addappid(3302473,0,"48e8fc6672f49bfa71934a13a2f53e4846315340e22d7be691de099e7db4d87d")
addappid(3655420)
addappid(3655421,0,"1e19f1c5c9d64d9892acde57b6b210141f37d8b0c605605eed1e8728be887dae")
