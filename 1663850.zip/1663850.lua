-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(1663850)
addappid(1663851,0,"6c5ad07d24ba971709a2773ed2263ddc46bf21f9a2608989ef9438668db72760")
