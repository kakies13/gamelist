-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(2416450)
addappid(2416451,0,"c52f8369321c8357293962eacf7c7f416c2ea912c3d2640703880a12c964732a")
addappid(3912890)
