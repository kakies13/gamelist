-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(229020)
addappid(603850)
addappid(603851,0,"03e3821f3ac71152e806701403e0c9252f4839c75291b5b3a585aacd9e962080")
addappid(603852,0,"25d7f7c9f3765d54ef8c92a699fe990ee5a27de93489240ee9f20d80a84c6ebe")
addappid(603853,0,"ed5f7d8ff33e68853445666e40b2b2e17085a515184b7438c527ccf46340effc")
