-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(228988)
addappid(229006)
addappid(261550)
addappid(261551,0,"16a71c423df683e98af58e40c60a6fc8087dc360f977a73c7d138e8d26b99062")
addappid(261552,0,"b6cfe4c61b9f19a7399a290c50b3dc18052f63b095401ffb3aa8286277597365")
addappid(2240110)
addappid(2927200)
