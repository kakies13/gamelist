-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(977950)
addappid(977951,0,"5e954d77ef1866e557c00b742437d480a7c03c2303b6a96268fbd1a55014839e")
addappid(977952,0,"7161eb622ca30debeb61bc87ecc80dd9a4cf78b7ef999fbc676710acd080565e")
addappid(977953,0,"cff06fc131de80d2131b228a0ec443303aa7b4fa8bf9b71b02ce9faa59f005c2")
addappid(977954,0,"85480edfffe7849f3714592a16a8fb97e94bb7fdc0773a9d9db0f80a40890bce")
addappid(1977570)
addappid(1977571,0,"a4ec8a574d6949e27a066e3ef02d87d50cc32e090944d977595132716b46ed40")
addappid(1977572,0,"b0d89adeb9338cee8859eb5596cfad872bdf7a96c8e58f53cb8f214857e5c481")
addappid(1977573,0,"51140ab9601562c890952d5b7022bc09726be1e7fc6d8dbbfc09f5318110f6f7")
addappid(1977574,0,"b74fb5a309784a778cb5d14cd6b64ee94da0fd481eef93e9b50fc183ca8b3b1f")
