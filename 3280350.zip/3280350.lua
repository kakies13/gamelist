-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(3280350)
addappid(3280351,0,"adedba4e249ea03aa263769ddb3bccd36a54816bbe471c73c51c5b1569187d00")
addappid(3280352,0,"4a43534f83813efc865429cc3edb56f45db455c86e8373827711e5c447f0d7e3")
addappid(3280354,0,"7010c7c1c501ba95ec42f5545dcfc4ee462ca97e854e4c0c3eccb61cbaf26c84")
addappid(3669120)
addappid(3669122,0,"640832b483b5a8f5dac50d55e17ef9a31d9b5f58f29b6ea5c85a41a0dfb0342b")
addappid(4119250)
