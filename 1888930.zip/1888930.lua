-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(1888930)
addappid(1888931,0,"19cd197b4bc7e62551196ec84d00da135a4dedeb5edca50804001bf9e90b6b70")
addappid(1888932,0,"20a675f9d2a0efd0cf0f8985b2a1c67d5d64e1c2b5aee665d3692969b28b1be4")
addappid(1888933,0,"035887e659bc052ab1d1801d1665304be7da49992076cd123e25b9bd06a64134")
addappid(2245260)
addappid(2254450)
