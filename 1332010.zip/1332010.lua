-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(1332010)
addappid(1332011,0,"e61bdb7aeaccc075f69345348178ac158f107c1433c9a28743797407dc335e4c")
addappid(1332012,0,"b0288825cade4cf4aceb6bf5a2e523e0c94028b45fe8095fea1f7e04e26f5728")
