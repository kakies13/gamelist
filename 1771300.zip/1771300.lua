-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(1771300)
addappid(1771302,0,"41bc41c39ce79db318e98b533bab1fe71bfd294c4e8c90f90e4f8efa5fcc2a91")
addappid(1771303,0,"397ab2e5c59bbb75f716c30dba3374be8af7ff49a2fc45c621e0bc23bafbd5f3")
addappid(1771305,0,"66d5a42e0171363eac9b79352c78401952d616880979d26967c385d2d7a88368")
addappid(1771306,0,"120aed0e767afa1ac85539240704d613b82c13473fcd7136d3cea555a784783e")
addappid(1771307,0,"8d47328b0b82d9b9ba25bfb199c69ea2dd005954298bd2aff2b448321569b727")
addappid(1771308,0,"b457fdf0e78f3465b9ccbfed5f8ecbb85f22428ba321534ee0df4a0d08754d02")
addappid(1771309,0,"1f8b55f9f4ac27eac8ffa310ca46163ee5aaad0937438035274a30b78de4e81a")
addappid(3118100)
addappid(3118101,0,"69d3aecd16754fea50cf46182e56be5d29647e571e45c1dd1ef3294b966d0ee4")
addappid(3118110)
addappid(3118120)
addappid(3119920)
addappid(3368600)
addappid(3368610)
addappid(3368620)
