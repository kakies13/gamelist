-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(3419520)
addappid(3419521,0,"7763e89ed36372394d459530e45e7dab3aca85588166e1c59d3bd1f7993bfac6")
addappid(3960620)
addappid(3960630)
addappid(3960640)
addappid(3960650)
addappid(3960660)
