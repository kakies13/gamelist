-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(1285190)
addappid(1285191,0,"aabb315ef5573fc2633c461cd2ac9b553e2713ca90a67ad2df09781274cbb20f")
addappid(1285192,0,"3e212ce90691e4e8f2f1418c35495c50a725bb0d012d9f415b0a8a9119dfb0f4")
addappid(1285193,0,"5c38ce39a639096877f707cb88dea4250f2a4b53ae5e1b67654e243d2b988ede")
addappid(2013850,0,"f0f6f03e213ec6effac974bc92309dc05e11e8d49013fabccdc253f8479d1c44")
addappid(3802360)
addappid(3802370)
addappid(3829670)
addappid(3829680)
