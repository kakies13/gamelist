-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(3357650)
addappid(3357651,0,"18e75bfb3f8c26b7a59d9e3a7013e74e1c59fe563aa00ee15f54a35b17691766")
addappid(3859920,0,"1fb811843160e2a11211f5bba90ece0ef2dac5994c19936e50ff85faf2f80423")
addappid(3859930,0,"14001799a6877a14751af43adbd59ca3cc037cf202aa5615e0c70e057090ddce")
