-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(2815070)
addappid(2815071,0,"daec92978f1e0a7c2eac9986cc7e2754d247b951584e6178d0e97cc4d29fa7bb")
addappid(3970220)
addappid(3970260)
addappid(3970270)
