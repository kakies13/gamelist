-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(3194360)
addappid(3194361,0,"2eab901f3297c0706ad8606e564f7913bf97b561233741ca20f0de137d4142f3")
