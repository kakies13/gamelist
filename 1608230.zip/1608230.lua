-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(1608230)
addappid(1608231,0,"111bd9a2a83debc63dae7c527c541ebaa1192ccce92e1ce0f44f41dea9bc75f7")
