-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(1044720)
addappid(1044721,0,"2a605d9a2257c347b93162b67aa9844b9719d858501c8df4bcf4982565069ab7")
