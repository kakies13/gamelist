-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(2868840)
addappid(2868841,0,"ed043fd4ac0899cd0b5fc59d5407115ff4f87793b162ba16fe49c7e2893938ab")
