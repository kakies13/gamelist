-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(1371980)
addappid(1371981,0,"9598cfe06b948f9eca5cbd915b40bec41730f61f6349bbd41d5ee6e86c47a3f6")
addappid(1371982,0,"d2a7d91fcd80393c3bf0c9e55165cba9c37c264dbe3eddb717215de20508e607")
