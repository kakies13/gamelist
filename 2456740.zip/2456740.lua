-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(2456740)
addappid(2456741,0,"e91cba2d1d471bdfb115bee76ac997858f84e6ab0a82af5f17d0054f8a3c9686")
addappid(3887680,0,"25ed1bd4d03ac4fd1a739171c82248fe6db511beea87dccfe33721091039e9c8")
