-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(1086940)
addappid(2378500,0,"77dfde8ac009c5a510843210ffa1343976be2cc3a303122c9c635fcba725d9cb")
addappid(1419653,0,"dc9bee49d256e78104b71d0bf90e9818631b069dce3b576a86fa6345d3b94896")
addappid(1419652,0,"43c13e12030aed1fdb00bd1c630bd68f0d22cb23289c879b00d7904aa05fcc89")
addappid(1086942,0,"5313c9d372b30e73c15606d9792e5f23314c21559d35f54eb7b5e8369e28b036")
addappid(1086941,0,"4876e089a6bb7a4d8da586306d4040c7d4bd5fb7c05da6c5441a760aa0b2bef6")
addappid(2378510) --Collector's Edition DLC
