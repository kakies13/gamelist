-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(2997230)
addappid(2997231,0,"a397e3852d84a423e6087d18c06db8f5a9123a2b20acee6f925c214b021dfd2d")
