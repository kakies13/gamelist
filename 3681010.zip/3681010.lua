-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(3681010)
addappid(3681011,0,"1c16eb875f0bd40521cc0ddb2ff4eb5772f0b1976252122abc5f9a09ddaaf995")
addappid(3681013,0,"b97a4048032dc27c3cf1c6887e6069b0f0d51da2c352c671278b00eb4423de35")
addappid(4003880)
addappid(4003890)
addappid(4003900)
addappid(4003910)
addappid(4003920)
addappid(4003930)
addappid(4003940)
addappid(4232000)
addappid(4232020)
addappid(4232030)
