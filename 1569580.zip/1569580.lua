-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(1569580)
addappid(1569581,0,"31965c819c33220b429da9fb8d633a2620f3b2b9e5f7ad47380878b719d85861")
addappid(1569582)
addappid(1569583)
