-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(3501070)
addappid(3501071,0,"7bb00da72e348f52d382147b41332f518de67a4ff8f3ab8cd203888982e72de4")
